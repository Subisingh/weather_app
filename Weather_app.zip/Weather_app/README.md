# Open-WeatherApp
A basic weather app made with HTML, CSS and JS and uses openweathermap API.
